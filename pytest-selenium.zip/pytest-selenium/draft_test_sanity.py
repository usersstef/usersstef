

from tests import  test_sttfunctions

test_sttfunctions.test_login()
test_sttfunctions.test_execute()


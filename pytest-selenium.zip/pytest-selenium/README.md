
# Install TR CLI
pip install trcli

# Install test project
pip install -r requirements.txt

# Run tests
pytest --junitxml "reports/junit-report.xml" "./tests"

# Upload test results
trcli -y -c "trcli-config.yml" parse_junit -f "reports/junit-report.xml"
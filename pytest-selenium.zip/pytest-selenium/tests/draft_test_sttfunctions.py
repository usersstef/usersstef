
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import NoSuchElementException
from pytest_testrail.plugin import testrail, pytestrail
from selenium.webdriver.common.by import By
from . import g_access
import time

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--incognito")
ServiceObj = Service('C:\Python\chrome_driver\chromedriver.exe')
driver = webdriver.Chrome(service = ServiceObj, options = chrome_options)
driver.maximize_window()

def test_login():
    if g_access.arg_c in g_access.user_dict:
        driver.get(g_access.SttHomePage); time.sleep(3)
        driver.find_element(By.XPATH, g_access.username_field).send_keys(g_access.user_dict[g_access.arg_c][0]); time.sleep(1)
        driver.find_element(By.XPATH, g_access.MicrosoftNext).click(); time.sleep(5)
        driver.find_element(By.XPATH, g_access.keep_signed_in).click; time.sleep(1)
        driver.find_element(By.XPATH, g_access.EANext).click(); time.sleep(18)
        driver.find_element(By.XPATH, g_access.password_field).send_keys(g_access.user_dict[g_access.arg_c][1]); time.sleep(1)
        driver.find_element(By.XPATH, g_access.EAVerify).click(); time.sleep(7)

        expected_elm = driver.find_element(By.XPATH, g_access.homepage_msg)

        try:
            assert expected_elm.text == "Welcome!"; print("Assertion Passed")
        except AssertionError:
            print("Assertion Failed")
            pass

def test_execute():
    driver.get(g_access.NewOrderPage); time.sleep(2)
    try:
        driver.find_element(By.XPATH, g_access.homepage_msg)
        print(" ")
    except NoSuchElementException:
        print("The New Order page doesn't contain the Welcome message, so the page is loaded successfully")
        pass
    
    driver.get(g_access.OrdersPage); time.sleep(2)
    driver.close()
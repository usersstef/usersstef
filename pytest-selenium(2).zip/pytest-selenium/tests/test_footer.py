
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.by import By
import random
import time


# Variables

filedropper = '//*[@id="app"]/div[2]/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[2]/div/div[2]/div[2]/div/div[2]/input'
projectcode = '317609'
projectcode_field = '//*[@id="app"]/div[2]/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[2]/div/div[3]/div[1]/div[2]/div[1]/div/input'
ordername = 'Default order'
ordername_field = '//*[@id="app"]/div[2]/div[2]/div/div/div[2]/div/div/div[1]/div/div/div[2]/div/div[3]/div[2]/div[2]/div/div/input'

# Test 1: Create an order and check if it's created

def test_1(browser_driver: WebDriver, record_property):
    time.sleep(5)
    record_property("testrail_result_comment", "1. Open the New Order page")
    browser_driver.get('https://mad-cmsweb-dev.ad.ea.com/stt/order')
    browser_driver.find_element(By.XPATH, filedropper).send_keys('C:\\Users\\sttataru\\Downloads\\Work\\ID78.wav'), time.sleep(2)
    for c in projectcode:
        browser_driver.find_element(By.XPATH, projectcode_field).send_keys(c)
    for c in ordername:
        browser_driver.find_element(By.XPATH, ordername_field).send_keys(c)
    browser_driver.find_element(By.XPATH, "//*[contains(text(), 'Next')]").click()
    browser_driver.find_element(By.XPATH, "//*[contains(text(), 'Finish')]").click(), time.sleep(1)
    assert browser_driver.find_element(By.XPATH, "//*[contains(text(), 'Default order')]").is_displayed()




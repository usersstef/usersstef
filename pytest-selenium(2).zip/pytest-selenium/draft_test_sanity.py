

from tests import  draft_test_sttfunctions

draft_test_sttfunctions.test_login()
draft_test_sttfunctions.test_execute()




from stt_package import  stt_functions

stt_functions.login_func()
stt_functions.execute_test()


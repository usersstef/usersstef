
import sys

# Login variables

arg_c = sys.argv[1]

user_dict = {
          "svc_loccmstester2@ea.com": "(A^FC!IW0xJ!Y)8NrGu9",
          "svc_loccmstester3@ea.com": "dedARzNE2mag2D&yol)#",
          "svc_loccmstester4@ea.com": "MgTB(d%xzkveIcvh6d(o",
          "svc_loccmstester5@ea.com": "!TL9MkK#TEZ%%AS1mC#v",
          "svc_loccmstester6@ea.com": "sXO4!LEFVB(ia$rsJEiq",
          "svc_loccmstester7@ea.com": "^X@LDq76(8)4@iKF3dB(",
          "svc_loccmstester8@ea.com": "#Zut%$9sR3!@!MpFn$a*",
          "svc_loccmstester9@ea.com": "69Hc2K5y*3J7$xI2qfVq",
          "svc_loccmstester10@ea.com": "(#nDBJ4l&)U!F43PrCx2",
          "svc_loccmstester11@ea.com": "gl6hJzCAb*iAyQCYF#oz",
          "svc_loccmstester12@ea.com": "pN5T1jVbc97Q%^E6mU!a",
          "svc_loccmstester13@ea.com": "EiwiReZG0(%lMvy9L4so",
          "svc_loccmstester14@ea.com": "5D70V&2GXgP)oYJNM$I&",
          "svc_loccmstester15@ea.com": "2%0f$G*tWOL!o7EsL7iY",
          "svc_loccmstester16@ea.com": "XAvJDRqMULg1!U0XLI6F",
          "svc_loccmstester17@ea.com": "2RNuA9#%NE23BkAIy1JC",
          "svc_loccmstester18@ea.com": "C9y()T5C2ED^7AOt3HO*",
          "svc_loccmstester19@ea.com": "17cVlfqE%gO^^R24Ents",
          "svc_loccmstester20@ea.com": "7*JGcVN$#Ji1(OvAY&Sy"
            }

email_field = '//div[@class="placeholderContainer"]//input[@type="email"]'
MicrosoftNext = '//*[@id="idSIButton9"]'
keep_signed_in = '//*[@id="form20"]/div[1]/div[3]/div[2]/div/span/div/label'
EANext = '//*[@id="form20"]/div[2]/input'
password_field = '//div[@data-se="o-form-input-container"]//input[@type="password"]'
EAVerify = '//*[@id="form21"]/div[2]/input'

# Execution variables

SttHomePage = 'https://mad-cmsweb-dev.ad.ea.com/stt'
NewOrderPage = 'https://mad-cmsweb-dev.ad.ea.com/stt/order'
OrdersPage = 'https://mad-cmsweb-dev.ad.ea.com/stt/orders'


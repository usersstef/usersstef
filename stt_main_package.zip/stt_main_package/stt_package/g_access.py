
import sys

# Login credentials and elements

arg_c = sys.argv[1]

user_dict = {
          'Eagle2': ("svc_loccmstester2@ea.com", "(A^FC!IW0xJ!Y)8NrGu9"),
          'Eagle3': ("svc_loccmstester3@ea.com", "dedARzNE2mag2D&yol)#"),
          'Eagle4': ("svc_loccmstester4@ea.com", "MgTB(d%xzkveIcvh6d(o"),
          'Eagle5': ("svc_loccmstester5@ea.com", "!TL9MkK#TEZ%%AS1mC#v"),
          'Eagle6': ("svc_loccmstester6@ea.com", "sXO4!LEFVB(ia$rsJEiq"),
          'Eagle7': ("svc_loccmstester7@ea.com", "fc9CiCx!HZIW%CQtAM(@"),
          'Eagle8': ("svc_loccmstester8@ea.com", "#Zut%$9sR3!@!MpFn$a*"),
          'Eagle9': ("svc_loccmstester9@ea.com", "69Hc2K5y*3J7$xI2qfVq"),
          'Eagle10': ("svc_loccmstester10@ea.com", "(#nDBJ4l&)U!F43PrCx2"),
          'Eagle11': ("svc_loccmstester11@ea.com", "gl6hJzCAb*iAyQCYF#oz"),
          'Eagle12': ("svc_loccmstester12@ea.com", "pN5T1jVbc97Q%^E6mU!a"),
          'Eagle13': ("svc_loccmstester13@ea.com", "EiwiReZG0(%lMvy9L4so"),
          'Eagle14': ("svc_loccmstester14@ea.com", "5D70V&2GXgP)oYJNM$I&"),
          'Eagle15': ("svc_loccmstester15@ea.com", "2%0f$G*tWOL!o7EsL7iY"),
          'Eagle16': ("svc_loccmstester16@ea.com", "XAvJDRqMULg1!U0XLI6F"),
          'Eagle17': ("svc_loccmstester17@ea.com", "2RNuA9#%NE23BkAIy1JC"),
          'Eagle18': ("svc_loccmstester18@ea.com", "C9y()T5C2ED^7AOt3HO*"),
          'Eagle19': ("svc_loccmstester19@ea.com", "17cVlfqE%gO^^R24Ents"),
          'Eagle20': ("svc_loccmstester20@ea.com", "7*JGcVN$#Ji1(OvAY&Sy")
            }

email_field = '//div[@class="placeholderContainer"]//input[@type="email"]'
MicrosoftNext = '//*[@id="idSIButton9"]'
keep_signed_in = '//*[@id="form20"]/div[1]/div[3]/div[2]/div/span/div/label'
EANext = '//*[@id="form20"]/div[2]/input'
password_field = '//div[@data-se="o-form-input-container"]//input[@type="password"]'
EAVerify = '//*[@id="form21"]/div[2]/input'

# Execution variables

SttHomePage = 'https://mad-cmsweb-dev.ad.ea.com/stt'
NewOrderPage = 'https://mad-cmsweb-dev.ad.ea.com/stt/order'
OrdersPage = 'https://mad-cmsweb-dev.ad.ea.com/stt/orders'

# Pass/Fail variables

greetings = "//*[contains(text(), 'Welcome')]"


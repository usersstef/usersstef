
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from . import g_access
import time
import sys

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--incognito")
ServiceObj = Service('C:\Python\chrome_driver\chromedriver.exe')
driver = webdriver.Chrome(service = ServiceObj, options = chrome_options)
driver.maximize_window()

def login_func():
    if g_access.arg_c in g_access.user_dict:
        driver.get(g_access.SttHomePage); time.sleep(3)
        driver.find_element(By.XPATH, g_access.email_field).send_keys(g_access.arg_c); time.sleep(1)
        driver.find_element(By.XPATH, g_access.MicrosoftNext).click(); time.sleep(5)
        driver.find_element(By.XPATH, g_access.keep_signed_in).click; time.sleep(1)
        driver.find_element(By.XPATH, g_access.EANext).click(); time.sleep(18)
        driver.find_element(By.XPATH, g_access.password_field).send_keys(g_access.user_dict[g_access.arg_c]); time.sleep(1)
        driver.find_element(By.XPATH, g_access.EAVerify).click(); time.sleep(5)
    
def execute_test():
    driver.get(g_access.NewOrderPage); time.sleep(2)
    driver.get(g_access.OrdersPage); time.sleep(2)
    driver.close()



import sys

arg1 = sys.argv[1]
arg2 = sys.argv[2]

if arg1 == "test1" and arg2 == "test2":
    print("The test arguments are printed!")
else:
    print("The arguments is invalid")
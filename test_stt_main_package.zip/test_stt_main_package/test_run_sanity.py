

from stt_package import  test_stt_functions

test_stt_functions.test_login()
test_stt_functions.test_execute()

